class MissingKeywordArgument(Exception):
	pass